## Checklist

{% example html %}
<ul class="checklist text-serif">
  <li>Single</li>
  <li>Taken</li>
  <li class="active">Pokémon Master</li>
</ul>
{% endexample %}
