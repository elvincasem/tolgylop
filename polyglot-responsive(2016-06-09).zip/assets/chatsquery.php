<?php
session_start();
$uid = $_SESSION['userid'];

?>
<?php 
include "dbconnect.php";
$conn = dbConnect(); 	
$chatid= $_POST['chatid'];
$accoun = $conn->prepare("SELECT count(*) as notif 
FROM tblconvo, tbluser
WHERE tblconvo.maincoid ='$uid'
AND tblconvo.friendcoid ='$chatid'
AND tbluser.userid ='$uid'
OR tblconvo.maincoid ='$chatid'
AND tbluser.userid ='$chatid'
AND tblconvo.friendcoid ='$uid'");;
$accoun->execute();
$res = $accoun->fetch(PDO::FETCH_ASSOC);
$condition =  $res['notif'];


$account = $conn->prepare("Select * FROM tbluser,tblconvo where tbluser.userid = tblconvo.friendcoid and tbluser.userid = '$chatid' or tblconvo.maincoid = '$chatid'");
$account->execute();
$result = $account->fetch(PDO::FETCH_ASSOC);

$name = $result['firstname']." ".$result['lastname'];
$profileP = $result['profileP'];

$userid = $result['userid'];


echo '<div class="modal-header">';
echo '<center><img class="img-circle media-object" src="img/'.$profileP.'"></center>';
echo '<center><h4><strong>'.$name.'</strong></h4></center>';
echo '<div class="input-group">
            <input type="text" placeholder="write a message" id = "convo" class="form-control" name="convo" >
            <input type="hidden" name="chatid" id="chatid" value="'.$chatid.'">
            <input type="hidden" name="uid" id="uid" value="'.$uid.'">
            <div class="input-group-btn">
              <button type="button" name = "submit"  class="btn btn-default" id ="send" onclick="convo('.$uid.')">
                <span><img src="img/send.png" width="20px" height="20px"></span>
              </button>
            </div>';
echo '</div>';



$chat = $conn->prepare("SELECT * 
FROM tblconvo, tbluser
WHERE tblconvo.maincoid ='$uid'
AND tblconvo.friendcoid ='$chatid'
AND tbluser.userid ='$uid'
OR tblconvo.maincoid ='$chatid'
AND tbluser.userid ='$chatid'
AND tblconvo.friendcoid ='$uid'");
$chat->execute();
while($cres = $chat->fetch(PDO::FETCH_ASSOC)){
  $chater = $cres['maincoid'];
 
}
 if($condition>0){

$chats = $conn->prepare("SELECT * 
FROM tblconvo, tbluser
WHERE tblconvo.maincoid ='$uid'
AND tblconvo.friendcoid ='$chatid'
AND tbluser.userid ='$uid'
OR tblconvo.maincoid ='$chatid'
AND tbluser.userid ='$chatid'
AND tblconvo.friendcoid ='$uid'");
$chats->execute();
while($chatres = $chats->fetch(PDO::FETCH_ASSOC)){
$name = $chatres['firstname']." ".$chatres['lastname'];
$profileP = $chatres['profileP'];
$comess = $chatres['conversation'];
echo '<br>';
echo '	<ul class="media-list media-list-conversation">
			<li class="media media-current-user m-b-md">
                <div class="media-body">
                  <div class="media-body-text" id = "conver">
                  '.$comess.'
                  </div>

                  <div class="media-footer" >
                    <small class="text-muted">
                      <a href="#">'.$name.'</a> at 4:20PM
                    </small>
                  </div>
                </div>
                <a class="media-right" href="#">
                  <img class="img-circle media-object" src="img/'.$profileP.'">
                </a>
              </div>
            </li>
            </ul>';
 
}
}else{
	echo '<h6><center>Start Conversation!</center></h6>';
}
?>
 <script type="text/javascript">

            function convo(ui){
                   alert(ui);
                   //alert(document.getElementById('comments').value);
			
				  // alert(comments);
                  //makeAjaxRequest(pid);
				  $.ajax({
                    url:    'convo.php',
                    type: 'post',
                    data: {uid:  $('input#uid').val(),chatid: $('input#chatid').val(), convo: $('input#convo').val()},
                    success: function(response) {
                      //console.log();
                      //$('table#resultTable tbody').html(response);
                      //alert('Posting Successful!');
                     //alert(response);
                      $('#conver').load(document.URL +  ' #conver');
                       //$('#counts-'+pid).load(document.URL +  ' #counts-'+pid);
                      //$('#comment').text = "";
                      document.getElementById('convo').value = "";
                    }
                  }); 
                }

                






              jQuery(document).ready(function($) {
                $('#send').click(function(){

                  makeAjaxRequest();
                });
                
                

              });
            </script>