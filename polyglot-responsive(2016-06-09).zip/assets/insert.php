
<?php
ob_start();
include 'dbconnect.php';
$conn = dbConnect();
$account = $conn->prepare("INSERT INTO tbluser (email, password, firstname, lastname, birthday, gender, language)
VALUES
('$_POST[email]','$_POST[pass]','$_POST[fname]','$_POST[lname]','$_POST[bday]','$_POST[gender]','$_POST[language]')");
$account->execute();
$result = $account->fetch(PDO::FETCH_ASSOC);

 if(count($result)>=1){

 header("Location: ../index.php");
 }else{
 echo 'no';
 }

?>
