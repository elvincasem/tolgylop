<?php
session_start();
ob_start();
include_once "dbconnect.php";

$conn = dbConnect();
$postid = $_POST['pid'];
$userid = $_SESSION['userid'];
$account = $conn->prepare("DELETE FROM tblpost WHERE postid = '$postid' and userid = '$userid'");
$account->execute();
$result = $account->fetch(PDO::FETCH_ASSOC);

if (count($result)>2) {
    
} else {
    header("Location: ../home.php");
}
/*if (!mysql_query($account,$conn))
  {
 die('Error: ' . mysql_error());
  }
 header("Location: ../main2.php");*/
 
//mysql_close($con)
?>

