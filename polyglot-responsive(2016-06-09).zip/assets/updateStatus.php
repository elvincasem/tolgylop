<?php
ob_start; 
include_once "dbconnect.php";

$conn = dbConnect();
session_start();
$follower=$_REQUEST['follower'];
$updateStat = $conn->prepare("Update tblfriendlist Set status='1' WHERE frienduserid = '".$_SESSION["userid"]."' AND mainuserid = '$follower'");
$updateStat->execute();
$account = $conn->prepare("INSERT INTO tblfriendlist ( mainuserid, frienduserid, status) VALUES ('" . $_SESSION["userid"] ."','$follower','1')");
$account->execute();
$account = $conn->prepare("INSERT INTO tblmessage ( mainmesid, friendmesid) VALUES ('" . $_SESSION["userid"] ."','$follower')");
$account->execute();
$account = $conn->prepare("INSERT INTO tblmessage ( friendmesid, mainmesid) VALUES ('" . $_SESSION["userid"] ."','$follower')");
$account->execute();

$result = $account->fetch(PDO::FETCH_ASSOC);
//echo "Update tblpost Set email='$_POST[email]', password='$_POST[pass]', firstname='$_POST[fname]', lastname='$_POST[lname]', birthday='$_POST[bday]', language='$_POST[language]' WHERE email='" . $_SESSION["email"] . "'";
echo count($result);
		
		print_r($result);
if(count($result)>1)
{echo "yes";
}else{
//echo "no";
header("Location: ../notifications/index.php");

}/*if (!mysql_query($account,$conn))
  {
 die('Error: ' . mysql_error());
  }
 header("Location: ../main2.php");*/
 
//mysql_close($con)
?>

